import React from 'react'
import Layout from 'layout'
import './styles/main.scss'

const App = () => <Layout />

export default App
